import  React, {useState} from 'react';
import{Text}from 'react-native';

export default function App() {
return(
  <Text>yay</Text>
)
}